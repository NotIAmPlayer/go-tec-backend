package controllers

import (
	"database/sql"
	"go-tec-backend/config"
	"log"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
	"golang.org/x/crypto/bcrypt"
)

type User struct {
	Nim      string `json:"nim"`
	Nama     string `json:"name"`
	Email    string `json:"email"`
	Password string `json:"password"`
}

type UpdatePasswordData struct {
	OldPassword string `json:"old_password"`
	NewPassword string `json:"new_password"`
}

func hashPassword(password string) (string, error) {
	bytes, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)

	return string(bytes), err
}

func GetAllUsers(c *gin.Context) {
	/*
		Get all users from the database as JSON.
	*/
	users := []User{}

	query := "SELECT nim, namaMhs, email FROM mahasiswa ORDER BY nim ASC"

	rows, err := config.DB.Query(query)

	if err != nil {
		log.Printf("Get multiple users error: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{
			"message": "500 - Internal server error",
		})
		return
	}

	defer rows.Close()

	for rows.Next() {
		var u User

		if err := rows.Scan(&u.Nim, &u.Nama, &u.Email); err != nil {
			log.Printf("Get multiple users error: %v", err)
			c.JSON(http.StatusInternalServerError, gin.H{
				"message": "500 - Internal server error",
			})
			return
		}

		users = append(users, u)
	}

	if len(users) == 0 {
		c.JSON(http.StatusOK, gin.H{
			"message": "200 - No users found",
		})
		return
	} else {
		c.JSON(http.StatusOK, users)
	}
}

func GetUser(c *gin.Context) {
	/*
		Get a user by NIM from the database as JSON.
	*/
	nim := c.Param("nim")

	var u User

	query := "SELECT nim, namaMhs, email FROM mahasiswa WHERE nim = ?"

	row := config.DB.QueryRow(query, nim)

	if err := row.Scan(&u.Nim, &u.Nama, &u.Email); err != nil {
		if err == sql.ErrNoRows {
			c.JSON(http.StatusNotFound, gin.H{
				"message": "404 - User not found",
			})
		} else {
			log.Printf("Get one user error: %v", err)
			c.JSON(http.StatusInternalServerError, gin.H{
				"message": "500 - Internal server error",
			})
		}
		return
	}

	c.JSON(http.StatusOK, u)
}

func CreateUser(c *gin.Context) {
	/*
		Create a new user in the database from JSON data.
	*/
	var u User

	if err := c.ShouldBindJSON(&u); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"message": "400 - Invalid JSON data",
		})
		return
	}

	hash, err := hashPassword(u.Password)

	if err != nil {
		log.Printf("Hashing password error: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{
			"message": "500 - Internal server error",
		})
		return
	}

	u.Password = hash

	query := "INSERT INTO mahasiswa (nim, namaMhs, email, password) VALUES (?, ?, ?, ?)"
	_, err = config.DB.Exec(query, u.Nim, u.Nama, u.Email, u.Password)

	if err != nil {
		log.Printf("Create user error: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{
			"message": "500 - Internal server error",
		})
		return
	}

	c.JSON(http.StatusCreated, gin.H{
		"message": "201 - User created successfully",
	})
}

func UpdateUser(c *gin.Context) {
	/*
		Update a user in the database from JSON data.
		Does not update password.
	*/
	nim := c.Param("nim")

	var u User

	if err := c.ShouldBindJSON(&u); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"message": "400 - Invalid JSON data",
		})
		return
	}

	updates := []string{}
	args := []interface{}{}

	if u.Nama != "" {
		updates = append(updates, "namaMhs = ?")
		args = append(args, u.Nama)
	}

	if u.Email != "" {
		updates = append(updates, "email = ?")
		args = append(args, u.Email)
	}

	if len(updates) == 0 {
		c.JSON(http.StatusBadRequest, gin.H{
			"message": "400 - No fields to update",
		})
		return
	}

	args = append(args, nim)
	query := "UPDATE mahasiswa SET " + strings.Join(updates, ", ") + " WHERE nim = ?"

	_, err := config.DB.Exec(query, args...)

	if err != nil {
		log.Printf("Update user error: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{
			"message": "500 - Internal server error",
		})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"message": "200 - User updated successfully",
	})
}

func UpdateUserPassword(c *gin.Context) {
	/*
		Update a user's password by NIM in the database from JSON data.
	*/
	nim := c.Param("nim")

	var u User

	if err := c.ShouldBindJSON(&u); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"message": "400 - Invalid JSON data",
		})
		return
	}

	if u.Password == "" {
		c.JSON(http.StatusBadRequest, gin.H{
			"message": "400 - No password to update",
		})
		return
	}

	hash, err := hashPassword(u.Password)

	if err != nil {
		log.Printf("Hashing password error: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{
			"message": "500 - Internal server error",
		})
		return
	}

	u.Password = hash

	query := "UPDATE mahasiswa SET password = ? WHERE nim = ?"
	_, err = config.DB.Exec(query, u.Password, nim)

	if err != nil {
		log.Printf("Update user password error: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{
			"message": "500 - Internal server error",
		})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"message": "200 - User password updated successfully",
	})
}

func UpdateAdminPassword(c *gin.Context) {
	/*
		Update a user's password by NIM in the database from JSON data.
	*/
	id := c.Param("id")

	var u User

	if err := c.ShouldBindJSON(&u); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"message": "400 - Invalid JSON data",
		})
		return
	}

	if u.Password == "" {
		c.JSON(http.StatusBadRequest, gin.H{
			"message": "400 - No password to update",
		})
		return
	}

	hash, err := hashPassword(u.Password)

	if err != nil {
		log.Printf("Hashing password error: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{
			"message": "500 - Internal server error",
		})
		return
	}

	u.Password = hash

	query := "UPDATE admin SET password = ? WHERE idAdmin = ?"
	_, err = config.DB.Exec(query, u.Password, id)

	if err != nil {
		log.Printf("Update user password error: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{
			"message": "500 - Internal server error",
		})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"message": "200 - User password updated successfully",
	})
}

func UpdateSelfPassword(c *gin.Context) {
	/*
		Update a user's own password. Usable for students and admins.
		Requires old password to replace to a new password.
	*/
	role, exists := c.Get("role")

	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "401 - Unauthorized"})
		return
	}

	userID, exists := c.Get("user_id")

	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "401 - Unauthorized"})
		return
	}

	var d UpdatePasswordData

	if err := c.ShouldBindJSON(&d); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"message": "400 - Invalid JSON data",
		})
		return
	}

	if d.OldPassword == "" {
		c.JSON(http.StatusBadRequest, gin.H{
			"message": "400 - Old password needed to update",
		})
		return
	}

	if d.NewPassword == "" {
		c.JSON(http.StatusBadRequest, gin.H{
			"message": "400 - No password to update",
		})
		return
	}

	var query string

	if role == "admin" {
		query = "SELECT password FROM admin WHERE idAdmin = ?"
	} else if role == "mahasiswa" {
		query = "SELECT password FROM mahasiswa WHERE nim = ?"
	}

	rows := config.DB.QueryRow(query, userID)

	var user UserData

	if err := rows.Scan(&user.Password); err != nil {
		if err == sql.ErrNoRows {
			c.JSON(http.StatusNotFound, gin.H{
				"message": "404 - Current user not found",
			})
		} else {
			log.Printf("Get self error: %v", err)
			c.JSON(http.StatusInternalServerError, gin.H{
				"message": "500 - Internal server error",
			})
		}
		return
	}

	if !comparePasswordHash(d.OldPassword, user.Password) {
		c.JSON(http.StatusNotFound, gin.H{
			"message": "400 - Old password is incorrect",
		})
		return
	}

	hash, err := hashPassword(d.NewPassword)

	if err != nil {
		log.Printf("Hashing password error: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{
			"message": "500 - Internal server error",
		})
		return
	}

	var query2 string

	if role == "admin" {
		query2 = "UPDATE admin SET password = ? WHERE idAdmin = ?"
	} else {
		query2 = "UPDATE mahasiswa SET password = ? WHERE nim = ?"
	}

	_, err = config.DB.Exec(query2, hash, userID)

	if err != nil {
		log.Printf("Update self password error: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{
			"message": "500 - Internal server error",
		})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"message": "200 - User password updated successfully",
	})
}

func DeleteUser(c *gin.Context) {
	/*
		Delete a user from the database.
	*/
	nim := c.Param("nim")

	query := "DELETE FROM mahasiswa WHERE nim = ?"
	_, err := config.DB.Exec(query, nim)

	if err != nil {
		log.Printf("Delete user error: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{
			"message": "500 - Internal server error",
		})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"message": "200 - User deleted successfully",
	})
}
